import React from 'react'

function BlogPostDetails() {
  return (
    <div>
      
    </div>
  )
}

export default BlogPostDetails

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const BlogPostList = () => {
  const [posts, setPosts] = useState([]);
  const [page, setPage] = useState(1);

  useEffect(() => {
    axios.get(`https://newsapi.org/v2/everything?q=tesla&from=2024-06-21&sortBy=publishedAt&apiKey=39945a252ad74448a22e063b55e27d1b`)
      .then(response => {
        setPosts(response.data.articles);
      });
  }, [page]);

  return (
    <div className="blog-list-container">
      {posts.map((post, index) => (
        <div key={index} className='blog-list-item'>
          <Link to={`/post/${index}`} className='blog-link'>
            {post.urlToImage && <img src={post.urlToImage} alt={post.title} className='blog-image' />}
            <div className='blog-content'>
              <h2>{post.title}</h2>
              <p>{post.description}</p>
              <p>{new Date(post.publishedAt).toLocaleDateString()}</p>
            </div>
          </Link>
        </div>
      ))}
      <div className="pagination-buttons">
        <button onClick={() => setPage(page - 1)} disabled={page === 1}>Previous</button>
        <button onClick={() => setPage(page + 1)}>Next</button>
      </div>
    </div>
  );
};

export default BlogPostList;
